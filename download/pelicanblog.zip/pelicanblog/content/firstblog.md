Title: First Blog Post
Date: 2015-8-08 13:10
Category: Blogging
Tags: blogging, markup
Slug: Blogging with Pelican
Author: yourname
Summary: Collection of notes related to programming and scripting.
Latex:

# Work in progress #
Following are examples of Pelican markup.

This is a **first** attempt to create static page with the help of _Pelican_.

